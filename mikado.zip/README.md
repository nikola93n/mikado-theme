# mikado-custom-theme
One page custom theme

# End
index.php, line 142, icons

# End 13.05.
Creating fields for the progress bar

# Version 0.7
Adding responsive number of Related project (ACF chnages script file)
Adding more places than two for related projects
Adding a latest bootstrap icons

# Version 0.8
Adding custom font to the theme customizer
